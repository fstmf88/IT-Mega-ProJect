terraform {
  required_version = "~> 1.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 6.0"
    }
  }
}

locals {
  conf = yamldecode(file("./variables.yaml"))
}

provider "aws" {
  region = local.conf.region
}

module "vpc" {
  source = "../modules/vpc"

  region                    = local.conf.region
  region_name               = local.conf.region_name
  az_list                   = local.conf.az_list
  number_of_azs             = local.conf.number_of_azs
  cidr_block                = local.conf.network.cidr_block
  subnet_bits               = local.conf.network.subnet_bits
  number_of_public_subnets  = local.conf.network.number_of_public_subnets
  number_of_private_subnets = local.conf.network.number_of_private_subnets
  number_of_nat_gws         = local.conf.network.number_of_nat_gws
}

module "sg" {
  source = "../modules/security-group"

  rules  = local.conf.rules
  vpc_id = module.vpc.vpc_id
}

module "keypair" {
  source = "../modules/keypair"

  key_info    = local.conf.key_info
  region_name = local.conf.region_name
}

resource "local_file" "private_key" {
  content              = module.keypair.private_key
  filename             = "${path.module}/id_${lower(local.conf.key_info.algorithm)}"
  file_permission      = "0600"
  directory_permission = "0700"
}
resource "local_file" "public_key" {
  content  = module.keypair.public_key
  filename = "${path.module}/id_${lower(local.conf.key_info.algorithm)}.pub"
}


module "ec2" {
  source = "../modules/ec2"

  region_name        = local.conf.region_name
  public_subnet_ids  = module.vpc.public_subnet_ids
  sg_ids             = module.sg.sg_ids
  key_name           = module.keypair.key_name
  ec2_instances      = local.conf.ec2_instances
  zone_id            = local.conf.zone_id
}

module "launch_template" {
  source = "../modules/launch-template"

  region_name     = local.conf.region_name
  launch_template = local.conf.launch_template
  sg_ids          = module.sg.sg_ids
  key_name        = module.keypair.key_name
}

module "target_group" {
  source = "../modules/target-group"

  target_groups = local.conf.target_group
  vpc_id        = module.vpc.vpc_id
}

module "autoscaling" {
  source = "../modules/autoscaling"

  public_subnet_ids  = module.vpc.public_subnet_ids
  target_group_arns  = module.target_group.target_group_arns
  lt_ids             = module.launch_template.launch_template_ids
  auto_grps          = local.conf.auto_grp
  autoscaling_policy = local.conf.autoscaling_policy
}

module "load-balancer" {
  source = "../modules/load-balancer"

  public_subnet_ids      = module.vpc.public_subnet_ids
  sg_ids                 = module.sg.sg_ids
  target_group_arns      = module.target_group.target_group_arns
  load_balancer          = local.conf.load_balancer
  load_balancer_listener = local.conf.load_balancer_listener
  load_balancer_rules    = local.conf.load_balancer_rules
  #key                    = "wordpress"
}

module "rds" {
  source = "../modules/rds"

  sg_ids           = module.sg.sg_ids
  subnet_ids       = module.vpc.private_subnet_ids
  db_instance      = local.conf.db_instance
  rds_subnet_group = local.conf.rds_subnet_group
}

module "iam_roles" {
  source = "../modules/iam_roles"
}

module "lambda" {
  source = "../modules/lambda"

  private_subnet_ids = module.vpc.private_subnet_ids
  sg_ids             = module.sg.sg_ids
  db_init            = local.conf.lambda_db_init
  rds_endpoint       = module.rds.rds_endpoint
  lambda_exec_arn    = module.iam_roles.lambda_exec_arn
}

module "route53" {
  source = "../modules/route53"

  zone_id      = local.conf.zone_id
  lb_dns_name  = module.load-balancer.lb_dns_name
  rds_endpoint = module.rds.rds_endpoint
}


module "waf" {
  source = "../modules/waf"

  log_group_arn = module.cloudwatch_logs.log_group_arn
  lb_arn        = module.load-balancer.lb_arn
}

module "cloudwatch_logs" {
  source = "../modules/cloudwatch_logs"
}