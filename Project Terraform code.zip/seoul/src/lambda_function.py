import json
import pymysql
import os

def lambda_handler(event, context):
    # TODO implement

    conn = pymysql.connect(host=os.environ['RDS_ENDPOINT'],
                            port = 3306,
                            user='admin',
                            password='Password')  
    cur = conn.cursor()
    file = open('main.sql', 'r', encoding='utf-8')
    read = file.read()
    file.close()

    rows = read.split(';\n')
    for row in rows:
        cur.execute(row)
    conn.commit()

    conn.close()

    return {
        'statusCode': 200,
        'body': json.dumps('DB Created')
    }
    
