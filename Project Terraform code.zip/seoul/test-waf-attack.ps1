# ============================================================
# WAF Test Attack Script
# SQL Injection, WordPress Attack, Brute Force Attack Test
# ============================================================

# Target URL (Domain set by Route53)
$targetUrl = "http://www.siu.it-edu.org"

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "WAF Attack Test Started" -ForegroundColor Cyan
Write-Host "Target: $targetUrl" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# ============================================================
# 1. SQL Injection Attack Test
# ============================================================
Write-Host "[1] SQL Injection Attack Test" -ForegroundColor Yellow

$sqlInjectionPayloads = @(
    '?id=1'' OR ''1''=''1',
    '?id=1'' UNION SELECT NULL--',
    '?id=1; DROP TABLE users--',
    '?id=1'' OR 1=1--',
    '/wp-login.php?user=admin''--'
)

foreach ($payload in $sqlInjectionPayloads) {
    $attackUrl = $targetUrl + $payload
    Write-Host "  Attack: $attackUrl" -ForegroundColor Gray
    
    try {
        $response = Invoke-WebRequest -Uri $attackUrl -Method GET -TimeoutSec 10 -UseBasicParsing
        Write-Host "  [X] Not blocked (HTTP $($response.StatusCode))" -ForegroundColor Red
    }
    catch {
        if ($_.Exception.Response.StatusCode.value__ -eq 403) {
            Write-Host "  [OK] Blocked by WAF (403 Forbidden)" -ForegroundColor Green
        }
        else {
            Write-Host "  [!] Response: $($_.Exception.Message)" -ForegroundColor Yellow
        }
    }
    Start-Sleep -Seconds 1
}

Write-Host ""

# ============================================================
# 2. WordPress Specific Attack Test
# ============================================================
Write-Host "[2] WordPress Specific Attack Test" -ForegroundColor Yellow

$wordpressAttacks = @(
    "/wp-admin/admin-ajax.php?action=revslider_show_image&img=../wp-config.php",
    "/wp-content/plugins/revslider/temp/update_extract/revslider/db.php",
    "/wp-login.php?action=lostpassword",
    "/xmlrpc.php",
    "/wp-includes/wp-version.php"
)

foreach ($path in $wordpressAttacks) {
    $attackUrl = $targetUrl + $path
    Write-Host "  Attack: $attackUrl" -ForegroundColor Gray
    
    try {
        $response = Invoke-WebRequest -Uri $attackUrl -Method GET -TimeoutSec 10 -UseBasicParsing
        Write-Host "  [X] Not blocked (HTTP $($response.StatusCode))" -ForegroundColor Red
    }
    catch {
        if ($_.Exception.Response.StatusCode.value__ -eq 403) {
            Write-Host "  [OK] Blocked by WAF (403 Forbidden)" -ForegroundColor Green
        }
        else {
            Write-Host "  [!] Response: $($_.Exception.Message)" -ForegroundColor Yellow
        }
    }
    Start-Sleep -Seconds 1
}

Write-Host ""

# ============================================================
# 3. Rate-based Brute Force Attack Test
# (Blocked if 15+ requests within 5 minutes)
# ============================================================
Write-Host "[3] Rate-based Brute Force Attack Test" -ForegroundColor Yellow
Write-Host "  Path: /wp-login.php (Blocked if 15+ requests in 5 min)" -ForegroundColor Gray
Write-Host "  Sending 16 requests quickly..." -ForegroundColor Gray

$bruteforceUrl = $targetUrl + "/wp-login.php"
$blockedCount = 0
$allowedCount = 0

for ($i = 1; $i -le 16; $i++) {
    Write-Host "  Request #$i..." -NoNewline -ForegroundColor Gray
    
    try {
        $response = Invoke-WebRequest -Uri $bruteforceUrl -Method GET -TimeoutSec 5 -UseBasicParsing
        Write-Host " Allowed (HTTP $($response.StatusCode))" -ForegroundColor Green
        $allowedCount++
    }
    catch {
        if ($_.Exception.Response.StatusCode.value__ -eq 403) {
            Write-Host " Blocked (403 Forbidden) [OK]" -ForegroundColor Red
            $blockedCount++
        }
        else {
            Write-Host " Other response: $($_.Exception.Message)" -ForegroundColor Yellow
        }
    }
    
    # Short delay for rapid consecutive requests
    Start-Sleep -Milliseconds 200
}

Write-Host ""
Write-Host "  Result: Allowed $allowedCount times, Blocked $blockedCount times" -ForegroundColor Cyan

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "WAF Attack Test Completed" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "[TIP] Check WAF metrics in CloudWatch:" -ForegroundColor Magenta
Write-Host "   - AWS Console > CloudWatch > Metrics > AWS/WAFV2" -ForegroundColor Magenta
Write-Host "   - SQLiRuleMetric, WordPressRuleMetric, BruteForceRuleMetric" -ForegroundColor Magenta
