variable "public_subnet_ids" {
  type = list(string)
}
variable "target_group_arns" {
  description = "Target_group ARNs"
  type        = map(string)
}
variable "lt_ids" {
  description = "Launch Template Ids"
  type        = map(string)
}

variable "auto_grps" {
  type = map(object({
    name                      = string
    health_check_type         = string
    health_check_grace_period = number
    desired_capacity          = number
    min_size                  = number
    max_size                  = number
    launch_template = object({
      template_name  = string
      instance_types = map(string)
    })
    target_group_key = string
  }))
}
variable "autoscaling_policy" {
  type = object({
    policy_type               = string
    name                      = string
    estimated_instance_warmup = number
    config = object({
      metric_type  = string
      target_value = number
    })
  })
}

