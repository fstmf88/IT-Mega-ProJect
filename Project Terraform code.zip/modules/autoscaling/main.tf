
resource "aws_autoscaling_group" "main" {
  for_each = var.auto_grps

  name                      = each.value.name
  vpc_zone_identifier       = var.public_subnet_ids
  target_group_arns         = [var.target_group_arns[each.value.target_group_key]]
  health_check_type         = each.value.health_check_type
  health_check_grace_period = each.value.health_check_grace_period
  desired_capacity          = each.value.desired_capacity
  min_size                  = each.value.min_size
  max_size                  = each.value.max_size
  tag {
    key                 = "Name"
    value               = each.value.name
    propagate_at_launch = true
  }

  mixed_instances_policy {
    launch_template {
      launch_template_specification {
        launch_template_id = var.lt_ids[each.value.launch_template.template_name]
        version            = "$Latest"
      }
      dynamic "override" {
        for_each = each.value.launch_template.instance_types
        content {
          instance_type     = override.key
          weighted_capacity = override.value
        }
      }
    }
  }
}

resource "aws_autoscaling_policy" "target_tracking" {
  for_each = aws_autoscaling_group.main

  name                      = "${each.value.name}-${var.autoscaling_policy.name}"
  autoscaling_group_name    = each.value.name
  policy_type               = var.autoscaling_policy.policy_type
  estimated_instance_warmup = var.autoscaling_policy.estimated_instance_warmup
  target_tracking_configuration {
    predefined_metric_specification {
      predefined_metric_type = var.autoscaling_policy.config.metric_type
    }
    target_value = var.autoscaling_policy.config.target_value
  }
}

# Instance Auto-Scaling 방식으로 생성 1
data "aws_instances" "asg_instances" {
  for_each = var.auto_grps

  filter {
    name   = "tag:aws:autoscaling:groupName"
    values = [each.value.name]
  }
}

# Instance Auto-Scaling 방식으로 생성 2
resource "aws_ec2_tag" "name_tag" {
  for_each = {
    for pair in flatten([
      for asg_key, asg in var.auto_grps : [
        for id in data.aws_instances.asg_instances[asg_key].ids : {
          id   = id
          name = asg.name
        }
      ]
    ]) : "${pair.id}-${pair.name}" => pair
  }
  resource_id = each.value.id
  key         = each.value.name
  value       = each.value.name
}
