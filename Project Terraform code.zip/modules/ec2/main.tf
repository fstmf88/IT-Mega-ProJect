locals {
  public_instances = flatten([
    for k, v in var.ec2_instances : [
      for i in range(v.count) : merge({
        for k2, v2 in v : k2 => v2
      }, { name = "${k}-${i + 1}" }) if v.public == true
    ]
  ])
}

resource "aws_instance" "public_instances" {
  count = length(local.public_instances)

  ami             = local.public_instances[count.index].ami_id
  instance_type   = local.public_instances[count.index].instance_type
  subnet_id       = var.public_subnet_ids[count.index % length(var.public_subnet_ids)]
  security_groups = [for x in local.public_instances[count.index].sg_names : var.sg_ids[x]]
  key_name        = var.key_name
  tags = {
    Name = "${var.region_name}-ec2-${local.public_instances[count.index].name}"
  }
  lifecycle {
    create_before_destroy = true
  }
}
# Instance으로 구동할 시 등록하는 Route53 Record
resource "aws_route53_record" "web" {
  count = length(aws_instance.public_instances)

  zone_id = "Z023288133I3LMUOUGUP8"
  name    = "${local.public_instances[count.index].name}.siu.it-edu.org"
  type    = "A"
  records = [aws_instance.public_instances[count.index].public_ip]
  ttl     = 60
}
