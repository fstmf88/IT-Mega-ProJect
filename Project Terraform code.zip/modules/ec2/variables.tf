variable "region_name" {
  type = string
}
variable "public_subnet_ids" {
  type = list(string)
}
variable "sg_ids" {
  type = map(string)
}
variable "key_name" {
  type = string
}
variable "zone_id" {
  description = "Route 53 Hosted Zone ID"
  type        = string
}
variable "ec2_instances" {
  type = map(object({
      count         = number
      ami_id        = string
      instance_type = string
      sg_names      = list(string)
      public        = bool
    }))
}

