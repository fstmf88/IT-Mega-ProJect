resource "aws_lb_target_group" "main" {
  target_type      = var.target_groups.wordpress.target_type
  name             = var.target_groups.wordpress.name
  protocol         = var.target_groups.wordpress.protocol
  port             = var.target_groups.wordpress.port
  ip_address_type  = var.target_groups.wordpress.ip_address_type
  vpc_id           = var.vpc_id
  protocol_version = var.target_groups.wordpress.protocol_version
  health_check {
    protocol            = var.target_groups.wordpress.health_check.protocol
    path                = var.target_groups.wordpress.health_check.path
    port                = var.target_groups.wordpress.health_check.port
    healthy_threshold   = var.target_groups.wordpress.health_check.healthy_threshold
    unhealthy_threshold = var.target_groups.wordpress.health_check.unhealthy_threshold
    timeout             = var.target_groups.wordpress.health_check.timeout
    interval            = var.target_groups.wordpress.health_check.interval
    matcher             = var.target_groups.wordpress.health_check.matcher
  }
}
