output "target_group_arns" {
  value = {
    wordpress = aws_lb_target_group.main.arn
  }
}

