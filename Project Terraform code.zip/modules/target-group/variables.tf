variable "vpc_id" {
  description = "AWS VPC`s ID"
  type        = string
}
variable "target_groups" {
  description = "Target Groups INFO"
  type = map(object({
      target_type      = string
      name             = string
      protocol         = string
      port             = number
      ip_address_type  = string
      protocol_version = string
      health_check = object({
          path                = string
          protocol            = string
          port                = string
          healthy_threshold   = number
          unhealthy_threshold = number
          timeout             = number
          interval            = number
          matcher             = string
        })
    }))
}


