variable "rds_subnet_group" {
  description = "db subnet group information"
  type = object({
    name        = string
    description = string
  })
}
variable "subnet_ids" {
  type = list(string)
}
variable "db_instance" {
  type = object({
    allocated_storage    = number
    db_name              = string
    engine               = string
    engine_version       = string
    instance_class       = string
    storage_type         = string
    username             = string
    password             = string
    parameter_group_name = string
    skip_final_snapshot  = bool
    publicly_accessible  = bool
    multi_az             = bool
  })
}
variable "sg_ids" {
  type = map(string)
}

