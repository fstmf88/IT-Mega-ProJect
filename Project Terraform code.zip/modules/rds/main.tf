resource "aws_db_subnet_group" "rds" {
  name       = var.rds_subnet_group.name
  subnet_ids = var.subnet_ids
}

resource "aws_db_instance" "main" {
  allocated_storage      = var.db_instance.allocated_storage
  db_name                = var.db_instance.db_name
  engine                 = var.db_instance.engine
  engine_version         = var.db_instance.engine_version
  instance_class         = var.db_instance.instance_class
  storage_type           = var.db_instance.storage_type
  db_subnet_group_name   = aws_db_subnet_group.rds.name
  vpc_security_group_ids = [var.sg_ids["rds"]]

  username             = var.db_instance.username
  password             = var.db_instance.password
  parameter_group_name = var.db_instance.parameter_group_name
  skip_final_snapshot  = var.db_instance.skip_final_snapshot
  publicly_accessible  = var.db_instance.publicly_accessible
  multi_az             = var.db_instance.multi_az
}

