variable "zone_id" {
  description = "Route 53 Hosted Zone ID"
  type        = string
}

variable "lb_dns_name" {
  description = "Load Balancer DNS"
  type        = string
}

variable "rds_endpoint" {
  description = "RDS Endpoint"
  type        = string
}

