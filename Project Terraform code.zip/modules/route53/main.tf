resource "aws_route53_record" "web" {
  zone_id = var.zone_id
  name    = "www.siu.it-edu.org"
  type    = "CNAME"
  records = [var.lb_dns_name]
  ttl     = 60
}

resource "aws_route53_record" "rds" {
  zone_id = var.zone_id
  name    = "rds.siu.it-edu.org"
  type    = "CNAME"
  records = [var.rds_endpoint]
  ttl     = 60
}

#resource "aws_route53_record" "gnu" {
#  zone_id = var.zone_id
#  name    = "gnu.siu.it-edu.org"
#  type    = "CNAME"
#  records = [var.lb_dns_name]
#  ttl     = 60
#}
