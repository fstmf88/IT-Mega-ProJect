data "archive_file" "lambda_zip" {
  type        = "zip"
  source_dir  = "../seoul/src"
  output_path = "../seoul/lambda_function.zip"
}

resource "aws_lambda_function" "db_init" {
  filename         = data.archive_file.lambda_zip.output_path
  function_name    = var.db_init.function_name
  role             = var.lambda_exec_arn
  handler          = var.db_init.handler
  runtime          = var.db_init.runtime
  timeout          = var.db_init.timeout
  source_code_hash = data.archive_file.lambda_zip.output_base64sha256
  environment {
    variables = { RDS_ENDPOINT = var.rds_endpoint }
  }
  vpc_config {
    subnet_ids         = var.private_subnet_ids
    security_group_ids = [var.sg_ids[var.db_init.vpc_config.sg_name]]
  }
}

resource "aws_lambda_invocation" "db_init" {
  function_name = aws_lambda_function.db_init.function_name
  input         = jsonencode({})
}

output "value1" {
  value = aws_lambda_invocation.db_init
}

