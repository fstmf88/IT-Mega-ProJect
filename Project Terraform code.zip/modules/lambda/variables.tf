variable "private_subnet_ids" {
  type = list(string)
}
variable "sg_ids" {
  type = map(string)
}
variable "rds_endpoint" {
  type = string
}
variable "lambda_exec_arn" {
  type = string
}
variable "db_init" {
  type = object({
    function_name = string
    handler       = string
    runtime       = string
    timeout       = number
    vpc_config = object({
      sg_name = string
    })
  })
}

