resource "aws_cloudwatch_log_group" "waf_logs" {
  name = "aws-waf-logs-alb"
}

