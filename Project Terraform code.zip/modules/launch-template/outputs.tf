output "launch_template_ids" {
  value = {
    for k, v in aws_launch_template.main : k => v.id
  }
}

