resource "aws_launch_template" "main" {
  for_each = var.launch_template

  name_prefix   = each.value.name_prefix
  description   = each.value.description
  image_id      = each.value.image_id
  instance_type = each.value.instance_type
  key_name      = var.key_name
  user_data     = base64encode(each.value.user_data)

  block_device_mappings {
    device_name = "/dev/xvda"
    ebs {
      volume_size           = 10
      volume_type           = "gp3"
      delete_on_termination = true
    }
  }

  network_interfaces {
    associate_public_ip_address = each.value.network_interfaces.associate_public_ip_address
    delete_on_termination       = each.value.network_interfaces.delete_on_termination
    security_groups             = [for name in each.value.sg_names : var.sg_ids[name]]
  }
  tags = { Name = "${var.region_name}-lt-${each.key}" }
}
