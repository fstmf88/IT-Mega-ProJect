output "key_name" {
  value = aws_key_pair.public_key.key_name
}

output "private_key" {
  value = tls_private_key.gen_key.private_key_openssh
}

output "public_key" {
  value = tls_private_key.gen_key.public_key_openssh
}

output "algorithm" {
  value = tls_private_key.gen_key.algorithm
}

