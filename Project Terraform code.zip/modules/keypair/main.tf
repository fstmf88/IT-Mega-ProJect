resource "tls_private_key" "gen_key" {
  algorithm = var.key_info.algorithm
  rsa_bits  = var.key_info.rsa_bits
}

resource "aws_key_pair" "public_key" {
  public_key = tls_private_key.gen_key.public_key_openssh
  key_name   = "${var.region_name}-${lower(tls_private_key.gen_key.algorithm)}-key"
}
