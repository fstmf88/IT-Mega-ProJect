variable "region" {
  description = "AWS Region"
  type        = string
  default     = "ap-northeast-2"
}

variable "region_name" {
  description = "AWS VPC`s Name"
  type        = string
}

variable "cidr_block" {
  description = "AWS VPC`s CIDR Block"
  type        = string
  default     = "10.2.0.0/24"
}

variable "number_of_public_subnets" {
  description = "VPC`s Public Subnet counts"
  type        = number
}

variable "number_of_private_subnets" {
  description = "VPC`s Private Subnet counts"
  type        = number
}

variable "az_list" {
  description = "AWS Region Availibility Zones Lists"
  type        = list(string)
}

variable "number_of_azs" {
  description = "AWS VPC`s Availibility Zones counts"
  type        = number
}

variable "subnet_bits" {
  description = "AWS VPC`s Subnet Bits counts"
  type        = number
}

variable "number_of_nat_gws" {
  type = number
}