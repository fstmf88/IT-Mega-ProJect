
output "vpc_id" {
  description = "VPC`s ID"
  value       = aws_vpc.main.id
}

output "public_subnet_ids" {
  value = local.public_subnet_ids
}

output "private_subnet_ids" {
  value = local.private_subnet_ids
}

