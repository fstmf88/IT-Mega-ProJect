variable "vpc_id" {
  description = "AWS VPC`s ID"
  type        = string
}

variable "rules" {
  description = "Per-service Security Groups"
  type = map(object({
    ingress_rules = map(object({
      protocol    = string
      from_port   = number
      to_port     = number
      cidr_blocks = list(string)
    }))
    egress_rules = map(object({
      protocol    = string
      from_port   = number
      to_port     = number
      cidr_blocks = list(string)
    }))
  }))
}
