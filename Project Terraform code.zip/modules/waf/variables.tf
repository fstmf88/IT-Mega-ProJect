variable "log_group_arn" {
  type = string
}
variable "lb_arn" {
  type = string
}
variable "rate_limit" {
  type    = number
  default = 180
}

