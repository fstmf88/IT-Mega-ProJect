
variable "public_subnet_ids" {
  description = "Public Subnets Ids List"
  type        = list(string)
}
variable "sg_ids" {
  description = "Security Groups Ids map"
  type        = map(string)
}
variable "target_group_arns" {
  description = "Target_group ARNs map"
  type        = map(string)
}

variable "load_balancer" {
  description = "Load Balancer INFO"
  type = object({
    load_balancer_type = string
    name               = string
    internal           = bool
    ip_address_type    = string
    sg_name            = string
  })
}
variable "load_balancer_listener" {
  description = "Load Balancer Listener INFO"
  type = object({
    protocol = string
    port     = number
    type     = string
  })
}

variable "load_balancer_rules" {
  description = "Load Balancer Rules"
  type = map(object({
    priority = number
    condition = object({
      host_header = object({
        values = list(string)
      })
    })
    action = object({
      type             = string
      target_group_key = string
    })
  }))
}

