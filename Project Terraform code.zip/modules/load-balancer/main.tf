
resource "aws_lb" "main" {
  load_balancer_type = var.load_balancer.load_balancer_type
  name               = var.load_balancer.name
  internal           = var.load_balancer.internal
  ip_address_type    = var.load_balancer.ip_address_type
  subnets            = var.public_subnet_ids
  security_groups    = [var.sg_ids[var.load_balancer.sg_name]]
}

resource "aws_lb_listener" "main" {
  load_balancer_arn = aws_lb.main.arn
  protocol          = var.load_balancer_listener.protocol
  port              = var.load_balancer_listener.port
  default_action {
    type             = var.load_balancer_listener.type
    target_group_arn = var.target_group_arns["wordpress"] # default to wordpress
  }
}

resource "aws_lb_listener_rule" "rules" {
  for_each = var.load_balancer_rules

  listener_arn = aws_lb_listener.main.arn
  priority     = each.value.priority

  action {
    type             = each.value.action.type
    target_group_arn = var.target_group_arns[each.value.action.target_group_key]
  }

  condition {
    host_header {
      values = each.value.condition.host_header.values
    }
  }
}

